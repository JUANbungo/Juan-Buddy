Juan Buddy - Cute 8-Bit Chiptune SFX & Pet Cries Pack (WAV + MIDI)
===================================================================

Folders Included:
1. wav_8bit/ui_movement/ (Crisp 8-bit retro WAV files ready for HTML5 Audio)
   - ui_button_click.wav   : Cute dual-tone blip for all UI buttons
   - ui_tab_pop.wav        : Soft pop for tabs/menus/portals
   - ui_confirm_chime.wav  : 3-note chime for Save Layout / Shop / Harvest
   - pet_walk_step.wav     : Cute tiny tip-tap step while Buddy walks
   - pet_fly_flap.wav      : Airy 8-bit wing flap for flying pets (Banog, Gagak, Dragon)
   - pet_tap_pat.wav       : Cute squishy boop-chirp when tapping/patting Buddy

2. wav_8bit/pet_cries/ (~1.1s - 1.5s unique 8-bit huni for every Juan Buddy pet!)
   - cry_egg.wav           : Egg wobble-tock
   - cry_kala.wav          : Kala (Carabao) - cute baby "Unga~!"
   - cry_bantay.wav        : Bantay (Aspin) - puppy "Arf-arf! Yip~"
   - cry_tala.wav          : Tala (Witchdog) - magical "Mew-ting!"
   - cry_muning.wav        : Muning (Cat) - kitten "Meow~ mrrp!"
   - cry_banog.wav         : Banog (Philippine Eagle) - proud "Kree-kree!"
   - cry_gagak.wav         : Gagak (Crow) - retro "Caw-caw!"
   - cry_ran.wav           : Ran (Snake) - cute rhythmic "Sss-hiss~"
   - cry_chai.wav          : Chai (Elephant) - baby trumpet "Pawoo~!"
   - cry_linh.wav          : Linh (Lotus Cat) - gentle chime-mew
   - cry_bara.wav          : Bara (Komodo) - cute dino-lizard chirp
   - cry_rimau.wav         : Rimau (Malayan Tiger) - tiger cub "Rawr-mew!"
   - cry_merli.wav         : Merli (Merlion) - bubbly water-roar
   - cry_raja.wav          : Raja (Bengal Tiger) - noble cub roar
   - cry_mochi.wav         : Mochi (Shiba Inu) - cheerful "Wan-wan!"
   - cry_bao.wav           : Bao (Panda) - cute panda bleat-squeak
   - cry_misha.wav         : Misha (Brown Bear) - cozy cub "Gruff-huu~"
   - cry_gino.wav          : Gino (Italian Pup) - melodic "Bau-bau!"
   - cry_dragon.wav        : Dragon (Inferno Dragon) - cute baby dragon roar + flame puff
   *(Note: Evolved pets like Bantay Evo, Dragon Evo, etc. automatically reuse their base pet cry!)*

3. midi/
   - Standard Type-0 8-bit square-lead MIDI (.mid) versions of all 25 sound effects.

===================================================================
COPY-PASTE PROMPT FOR MISTRAL AI:
===================================================================

Integrate the 8-bit cute sound effects from `juan_buddy_8bit_sfx_pack.zip` (extracted into `assets/sfx/`) into Juan Buddy, respecting the existing Sound On/Off toggle in the header/options:

1. UI Button & Menu Sounds:
   - Play `assets/sfx/wav_8bit/ui_movement/ui_button_click.wav` whenever any standard game button is clicked (Start, Play, Work, Sleep, Cheer Me Up, Shop, Explore, Farm tools, etc.).
   - Play `assets/sfx/wav_8bit/ui_movement/ui_tab_pop.wav` when switching tabs (Home / Park / Farm), opening the `+` drawer, or opening modals/portals.
   - Play `assets/sfx/wav_8bit/ui_movement/ui_confirm_chime.wav` when saving Home layout, purchasing an item, or harvesting/selling crops.

2. Buddy Walking & Flying Sounds (Throttled so they never overlap/spam):
   - While the active Buddy is walking, play `assets/sfx/wav_8bit/ui_movement/pet_walk_step.wav` softly (volume ~0.28) every ~380ms.
   - When a flying pet (`Banog`, `Banog Evo`, `Gagak`, `Gagak Evo`, `Dragon`, `Dragon Evo`) is flying/hovering in motion, play `assets/sfx/wav_8bit/ui_movement/pet_fly_flap.wav` softly (volume ~0.32) every ~450ms instead of footsteps.

3. Pet Tap / Pat + Pet-Specific 1–2s Cry ("Huni") ONLY When Tapped:
   - When the player directly clicks/taps the active Buddy sprite to pet/greet it:
     - Play `assets/sfx/wav_8bit/ui_movement/pet_tap_pat.wav` AND play the active pet's matching 1–2s cry from `assets/sfx/wav_8bit/pet_cries/cry_<petId>.wav` (mapping evolved forms like `bantay_evo` -> `cry_bantay.wav`, `dragon_evo` -> `cry_dragon.wav`, etc.).
     - Add a short cooldown (~1.5s) on the pet cry so rapid tapping does not overlap multiple cries on top of each other.
     - IMPORTANT: Pet cries must ONLY play when the player taps/pats the Buddy—do NOT play cries randomly while idle.
