JUAN BUDDY - BATTLE ARENA EXPANSION PACK
=========================================
Includes Attack & Hurt/Defeated animations for all 8 enemies + 3 Pixel-Art Battle Arena Backgrounds!

1. monsters/<monster_name>/
   - attack/
     * frames/ (6 transparent 128x128 PNG frames: windup, crouch, lunge+VFX, strike+VFX, recoil, recover)
     * <monster>_attack_spritesheet.png (768x128)
     * <monster>_attack_preview.gif
   - hurt_defeated/
     * frames/ (4 transparent 128x128 PNG frames: white hit-flash, red stagger, dizzy KO stars, defeated poof)
     * <monster>_hurt_defeated_spritesheet.png (512x128)
     * <monster>_hurt_defeated_preview.gif

   Monsters covered:
   guard_slime, cave_bat, wild_boar, ridge_wolf, kumiho, oni_brute, ember_wyvern, void_titan

2. arena_backgrounds/ (640x360 crisp 16-bit pixel art, 160x90 native scaled 4x)
   - arena_meadow_day.png   (For Guard Slime, Wild Boar, Ridge Wolf)
   - arena_cavern_night.png (For Cave Bat, Oni Brute)
   - arena_mystic_boss.png  (For Kumiho, Ember Wyvern, Void Titan)
