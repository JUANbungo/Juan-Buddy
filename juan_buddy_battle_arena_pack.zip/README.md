# Juan Buddy — Battle Arena, Monsters & Death/Revive Pack

## Contents
- `assets/arena/arena_bg.png` — 640×360 crisp pixel-art Battle Arena background
- `assets/monsters/<monster_id>/` — All 8 monsters (`guard_slime`, `cave_bat`, `wild_boar`, `ridge_wolf`, `kumiho`, `oni_brute`, `ember_wyvern`, `void_titan`), each with:
  - `idle_sheet.png` (4-frame horizontal sprite sheet)
  - `walk_sheet.png` (4-frame horizontal sprite sheet)
  - `idle_0.png` .. `idle_3.png` and `walk_0.png` .. `walk_3.png`
- `assets/death/` — `pet_ghost_idle_sheet.png`, `pet_ghost_walk_sheet.png`, `pet_tombstone_idle_sheet.png` (+ individual frames)
- `assets/items/` — `reincarnation_stone.png`, `special_reincarnation_stone.png`
- `assets/preview_roster_sheet.png` — Visual overview of all 12 sprites
- `js/battle-arena.js` — Complete Battle Arena + Death/Lockout + Reincarnation Shop engine
- `css/battle-arena.css` — Crisp pixel-art styling & 4-frame sprite animations
- `preview_demo.html` — Double-click to preview & test everything immediately in your browser
- `MISTRAL_AI_PROMPT.txt` — Copy-paste prompt for Mistral AI integration into `JUANbungo/Juan-Buddy`
