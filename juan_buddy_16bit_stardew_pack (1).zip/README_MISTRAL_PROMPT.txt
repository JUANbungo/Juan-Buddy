Juan Buddy - 16-Bit Stardew-Style Home, Park Portal & Farm Pack
=================================================================

Folders & Assets Included (all crisp 16-bit PNGs, transparent backgrounds):
- home/furniture/ : cozy_bed.png, toy_box.png, flower_vase.png, door_closed.png, door_open.png
- home/walls/     : wall_cozy_night.png, wall_pastel_cream.png, wall_bamboo_zen.png, wall_sky_clouds.png
- park/           : park_bg.png, explore_portal.png
- farm/           : farm_bg.png, soil_dry.png, soil_wet.png,
                    crop_berry_stage1.png / stage2.png,
                    crop_flower_stage1.png / stage2.png,
                    crop_plant_stage1.png / stage2.png,
                    tool_watering_can.png, tool_fertilizer.png,
                    beehive.png, bee_frame1.png, bee_frame2.png

=================================================================
COPY-PASTE PROMPT FOR MISTRAL AI:
=================================================================

Implement the Upgraded Home, Park + Explore Asia Portal, and Farm Ecosystem in Juan Buddy using the extracted 16-bit assets in `juan_buddy_16bit_stardew_pack.zip` (apply `image-rendering: pixelated` on all sprites):

1. UPGRADED EDITABLE HOME & SHOP:
   - Render Cozy Bed (`home/furniture/cozy_bed.png`) and Toy Box (`home/furniture/toy_box.png`) as visible 16-bit furniture models inside Buddy's Home once owned in the Shop.
   - Add a new Shop item: Flower Vase (`home/furniture/flower_vase.png`) that can be purchased and placed in Buddy's Home.
   - Add a Wall Design switcher using `wall_cozy_night.png`, `wall_pastel_cream.png`, `wall_bamboo_zen.png`, and `wall_sky_clouds.png` so players can change their room wallpaper anytime.
   - Add an "Edit Home" mode where players can drag-and-drop Cozy Bed, Toy Box, Flower Vase, and other home furniture anywhere inside the room, with a "Save Layout" / "Cancel" confirmation bar that saves coordinates to localStorage.
   - Place an interactive Door (`door_closed.png` / `door_open.png`) in Buddy's Home. Clicking it opens the door and moves the Buddy outside to the Park scene.

2. PARK SCENE & EXPLORE ASIA PORTAL:
   - Create a "Park" view (`park/park_bg.png`) where the Buddy walks outside, with "Back to Home" and "Go to Farm" buttons.
   - Place the glowing Portal (`park/explore_portal.png`) inside the Park. Clicking it opens a modal listing all 6 Explore Asia destinations (Barangay Park, Manila Baywalk, Floating Market, Kyoto Zen Garden, Rice Terraces, Boracay Beach); clicking any location travels there immediately.

3. ECO-FARM SYSTEM:
   - Create a "Farm" view (`farm/farm_bg.png`) accessible from the Park or Menu, featuring a grid of plantable soil plots (`soil_dry.png` -> `soil_wet.png` when watered).
   - Support planting 3 crop types: Berries (`crop_berry_*`), Flowers (`crop_flower_*`), and Plants (`crop_plant_*`), growing from stage1 to harvestable stage2 crops that reward coins/snacks/eco-points.
   - Add interactive tools: Watering Can (`tool_watering_can.png`) to water dry plots and speed growth, and Fertilizer (`tool_fertilizer.png`) for instant growth boost.
   - Allow placing a Beehive (`beehive.png`) with animated flying Bees (`bee_frame1.png`, `bee_frame2.png`) to boost the Farm Ecosystem score and give passive growth-speed and harvest bonuses.
