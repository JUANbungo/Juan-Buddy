JUAN-BUDDY COMPLETE EVOLUTION, EQUIPMENT & COZY UI PACK
=======================================================
1. evolutions/sheets/ (14 Animated Stage-2 Evolution Sprite Sheets, 4x5 grid, 128x128 per frame)
   - Datu Bantay, Bathala Kala, Archmage Tala (Witchdog), Maharaja Chai, Empress Linh,
     Raja Naga Bara, Sultan Rimau, Poseidon Merli, Samrat Raja, Gajendra Moti,
     Shogun Mochi, Emperor Bao, Tsar Misha, Doge Gino
   - evolutions/single/ : Ready-to-use per-state PNGs (idle, walk, happy, eat, sleep)
2. items/cosmetics/ (12 Cute 64x64 Transparent PNG Cosmetics: Hats, Scarves, Wings, Auras)
3. items/equipment/ (8 RPG 64x64 Transparent PNG Equipment: Swords, Shields, Agimat, Evo Stone, Ring)
4. ui/ (Cozy Animal-Friendly Parchment Panels, HUD Top Bar, 4 Pill Button Themes, & HUD Icons)
5. evolution_ui_manifest.json : Full JSON config for wiring into Juan-Buddy!
