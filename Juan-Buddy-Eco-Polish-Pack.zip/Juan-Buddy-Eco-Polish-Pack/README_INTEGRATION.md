# Juan-Buddy — Eco-Friendly 16-bit Polish Pack

Lahat ng assets, CSS themes, at micro-animation scripts sa ZIP na ito ay naka-align sa iisang eco-friendly 16-bit palette (Deep Forest Ink `#1F3327`, Warm Parchment `#F4EFE6`, Sage/Leaf Green `#5F8D62` / `#88B04B`, Terracotta `#C96F53`, at Sunlight Gold `#E8B959`).

## Mabilisang Preview
Buksan lang ang `preview/eco_preview.html` sa browser mo para makita agad nang live ang lahat ng icons, growing vine EXP bar, 4 eco-themes, at falling leaves / fireflies animation.

## Paano I-integrate sa `src/dashboard/`
1. Kopyahin ang `css/`, `js/`, at `assets/` folders sa loob ng `src/dashboard/` (o i-merge sa kasalukuyang `assets/` folder mo).
2. Sa `src/dashboard/index.html`, idagdag sa `<head>`:
   ```html
   <link rel="stylesheet" href="css/eco-theme.css">
   ```
3. Bago ang `</body>`, idagdag:
   ```html
   <script src="js/eco-particles.js"></script>
   ```
4. Magdagdag ng `class="eco-polished"` sa `<body>` tag.

## Built-in JavaScript Helpers (`window.JuanBuddyEco`)
- **Palitan ang Eco-Theme sa Options:**
  `JuanBuddyEco.setTheme('bamboo-grove')`
  `JuanBuddyEco.setTheme('rice-terraces')`
  `JuanBuddyEco.setTheme('terracotta-clay')`
  `JuanBuddyEco.setTheme('night-fireflies')`
- **Sync Day/Night Particles (Sunny vs Night):**
  `JuanBuddyEco.setTimeOfDay('day')` (nahuhulog na dahon)
  `JuanBuddyEco.setTimeOfDay('night')` (lumilipad na alitaptap)
- **Compost Sparkle kapag naglinis ng 💩💧:**
  `JuanBuddyEco.burst(event.clientX, event.clientY, 'compost')`

## Laman ng ZIP
- `css/eco-theme.css` — 4 eco color presets, bamboo/parchment panels, banig HUD accent, growing vine EXP bar, wooden bulletin banner frames, at soft terracotta care warning.
- `js/eco-particles.js` — Ambient leaves/fireflies canvas overlay + click/clean burst sparkles + theme switcher.
- `assets/icons/` (26 crisp 16-bit PNGs) — Pinapalitan ang system emojis sa HUD, menu tabs, streak evolution (`seed -> sprout -> sapling -> tree`), stat bars, gold leaf coin, wilted leaf warning, golden sprout level-up, at egg in woven nest.
- `assets/ui/` (10 crisp 16-bit PNGs) — 9-slice bamboo & wood frames, tileable banig trim, bamboo trough + vine EXP bar, Play/Work/Sleep/Cheer eco buttons, at wooden bulletin board frame.
- `assets/particles/` (6 PNGs) — Leaves, petal, firefly, droplet, compost sparkle.
- `assets/decor/` (5 PNGs) — Potted Sampaguita, Mini Bamboo, Solar Lamp, Wooden Compost Bin, at Wishing Seed Pod (para sa Wishing Tree / Gacha reskin).
