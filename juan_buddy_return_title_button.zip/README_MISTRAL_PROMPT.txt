Juan Buddy - Return to Title Screen Red Button Pack
====================================================

Files included (transparent PNG, zero blank space/margins):
- return_title_btn.png         (440x104 - Recommended HD / Retina)
- return_title_btn_hover.png   (440x104 - Hover state)
- return_title_btn_pressed.png (440x104 - Active/pressed state)
- return_title_btn_1x.png      (220x52  - Standard 1x size)
- return_title_btn_hover_1x.png(220x52  - Standard 1x hover)

Copy-Paste Prompt for Mistral AI:
---------------------------------
Replace the "Return to Title Screen" button in Buddy's Home with the custom red button image `return_title_btn.png` (and swap to `return_title_btn_hover.png` on hover, `return_title_btn_pressed.png` on active).
- Remove the old dark background, CSS border, padding, and HTML text inside the button so only the button art renders.
- Style the button with `background: transparent; border: none; padding: 0; line-height: 0; cursor: pointer; display: inline-flex; align-items: center;`
- Style the `<img>` inside with `display: block; height: 42px; width: auto; object-fit: contain;` (matching the exact height of the Play, Work, Sleep, and Cheer Me Up buttons) so the art fits cleanly with zero blank space.
- Keep the existing click handler to return to the Title Screen.
