JUAN BUDDY - EXPLORE ASIA 8-BIT ASSET PACK
==========================================
- Native 8-bit grid: 160x100 upscaled 4x (NEAREST) to 640x400 PNGs with clean transparent backgrounds.
- Every folder includes:
  * bg_day.png, bg_sunset.png, bg_night.png
  * 4-frame / 8-frame horizontal sprite sheets for all requested animations
  * preview_<location>.gif so you can preview the animations right away!
- Also includes `explore_manifest.json` (with exact coordinates & Floating Market water_zone) and `MISTRAL_AI_PROMPT.txt` ready to paste into Mistral AI.
